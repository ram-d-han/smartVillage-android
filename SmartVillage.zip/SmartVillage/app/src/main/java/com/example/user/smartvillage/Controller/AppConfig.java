package com.example.user.smartvillage.Controller;

public class AppConfig {
    private static final String ROOT_URL = "http://192.168.43.84/smartvillage/api/web/v1/";
    public static final String URL_REGISTER = ROOT_URL + "auth/register";
    public static final String URL_LOGIN= ROOT_URL + "auth/login";
    public static final String URL_GET_DATA_PEMBANGGUNAN= ROOT_URL + "pembangunan";
    public static final String URL_PICTURE = "http://159.89.194.1/smartvillage/backend/";

}
