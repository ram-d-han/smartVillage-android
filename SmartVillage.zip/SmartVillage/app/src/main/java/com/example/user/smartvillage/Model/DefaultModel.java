package com.example.user.smartvillage.Model;

/**
 * Created by user on 28/12/2017.
 */

public class DefaultModel {
    private boolean status;
    private String message;

    public boolean isStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

}
